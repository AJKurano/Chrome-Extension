<html>
 <title> AJ Kurano
  </title>
  <body>  <a href="https://www.youtube.com/channel/UCFM0dDr8Vi_he7Zhs6Fls6g?sub_confirmation=1">
    <button> click here to open the AJ Kurano YouTube Channel!!! </button>
    </a>
   This Extension Was Made By AJ Kurano for everyone. This site can't be used for personal or commercial purposes. You can't copy and edit or remix the original copy.
   You can use this for making a review or reaction video but you have to give me the original credit in the description. Please Don't Mess with the code. Have Fun!.
   <br>
   Steps To Use The File :
   <br>
   1. Download the File
   <br>
   2. Unzip The File
   <br>
   3. Go to chrome and type this "chrome://extensions/"
   <br>
   4. Drag The Downloaded Folder to the page
   <br>
   5. Enjoy Your Extension, You can open the links by right clicking on them!
   <br>
    <a href="AJ Kurano Chrome Extension.zip" download>
    <button> Download The Extension!!! </button>
  </body>
  </html>